# 牛草山 / 太子尖自动预测留档 v1.0

## 需要上传的两个文件（必须保留目录结构）

- `.github/workflows/cloudsea_archive.yml`
- `scripts/collect.py`

上传到现有 `gu422912289-svg/-niucaoshan-cloud-watch` 仓库 **根目录**。

GitHub 网页操作：打开仓库 → **Add file → Create new file**，文件名分别填入完整路径 `.github/workflows/cloudsea_archive.yml` 和 `scripts/collect.py`，把对应文件文本全部粘贴后提交。也可以电脑解压 ZIP，把两个文件及其目录上传，注意隐藏的 `.github` 文件夹。

## 启动和验收

1. 进入仓库 **Actions** → 找到 `Cloud Sea Forecast Snapshots`。
2. 点击 **Run workflow** 手动运行一次（如首次需要启用 Actions，先启用）。
3. 检查运行详情：`Collect and archive forecast data` 完成，随后 `Commit snapshot files` 成功。
4. 在仓库根目录找到 `snapshots/niucaoshan/2026-10/` 与 `snapshots/taizijian/2026-10/`（月份以实际运行时间为准）。
5. 打开 JSON，看 `capture_beijing`、`forecast_target_dates`、`datasets` 的 `error` 字段；所有 `error:null` 代表本轮五组请求都成功。
6. **Settings → Actions → General → Workflow permissions** 应选 `Read and write permissions`。如果 GitHub 企业或组织策略不允许写入，需按仓库权限修正；现有聊天 GitHub 连接的 403 不影响 Actions 自身令牌是否可写。

## 定时与预测范围

- 北京时间每天约 **08:10、20:10**，GitHub 定时任务可能延迟或跳过，实际时刻看文件内 `capture_beijing`。UTC cron为 `10 0,12 * * *`。
- 每次记录**采集当天及之后3天**，因此跨越日出、日落，同时保留更新前后的不同预测。
- 两个观测点：牛草山（31.044687, 116.265979，1350m）；太子尖（30.175600, 118.899700，1557m）。
- 每个点采集五组：综合地面、ECMWF地面、GFS地面、ECMWF气压层、GFS气压层；单次 JSON 包含4天逐小时原始返回以及采集时间、请求URL、错误信息。
- **永不主动覆盖历史快照**；GitHub 有版本记录，但长期 JSON 会占用仓库存储，需要定期观察文件大小。

## 关键边界（不要误解）

- 这是自动的**原始预测数据留档器**，不会修改 V4.13.1 网页，也**尚未运行 V4.13.1 的实际评分算法**。每份 JSON 的 `web_app_scores` 为 `null`，明示未计算；`diagnostics` 是单纯统计原始数据，不是评分。
- Open-Meteo Forecast API 不保证直接显示模式初始化 `run_id`，因此标为未知。若要真正检验固定起报时次，应进一步接入 Open-Meteo Single Runs / Previous Runs API。
- ECMWF、GFS、综合模式所选网格不同，气压层位于模式地面以下的值不能用作真实山体观测。
- 不存在照片的日期标为 **未验证**；没有实况不等于预报正确。事后回查不代替事前冻结。
- 天气数据与位置、预报来源可能有使用条款或调用限制；需尊重 Open-Meteo 和底层数据许可。

## 常见失败

- Actions 中找不到工作流：确认文件路径以 `.github/workflows/` 开头且已提交到默认分支。
- `403 Resource not accessible by integration`：检查本仓库 Actions 工作流权限为可写，且没有分支保护禁止 Actions 推送。
- 气象接口偶尔429或超时：脚本重试；仍失败也保存 `error`，不会伪装为0%。下一次定时自动重新采集。
- 定时运行不准时：正常；也可以手动 `Run workflow`。
